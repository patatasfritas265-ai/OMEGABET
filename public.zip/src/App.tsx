import React, { useState } from "react";

const PASSWORD = "6940WEWE";

type GameKey = "mines" | "limbo" | "blackjack" | "baccarat" | "races" | "roulette";

type GameProps = {
  balance: number;
  setBalance: React.Dispatch<React.SetStateAction<number>>;
};

/* -------------------- APP PRINCIPAL -------------------- */

const App: React.FC = () => {
  const [balance, setBalance] = useState(0);
  const [currentGame, setCurrentGame] = useState<GameKey | null>(null);
  const [walletOpen, setWalletOpen] = useState(false);
  const [walletAmount, setWalletAmount] = useState("");
  const [walletMode, setWalletMode] = useState<"deposit" | "withdraw">("deposit");
  const [walletPassword, setWalletPassword] = useState("");
  const [globalMessage, setGlobalMessage] = useState<string>("Bienvenido al casino demo.");

  function handleWalletConfirm() {
    const amount = Number(walletAmount);
    if (!isFinite(amount) || amount <= 0) {
      alert("Cantidad inválida.");
      return;
    }
    if (walletPassword !== PASSWORD) {
      alert("Contraseña incorrecta.");
      return;
    }
    if (walletMode === "withdraw") {
      if (amount > balance) {
        alert("No tienes saldo suficiente.");
        return;
      }
      setBalance((b) => b - amount);
      setGlobalMessage(`Retiraste ${amount.toFixed(2)} créditos. 💸`);
    } else {
      setBalance((b) => b + amount);
      setGlobalMessage(`¡Depósito de ${amount.toFixed(2)} créditos! 💰`);
    }
    setWalletAmount("");
    setWalletPassword("");
    setWalletOpen(false);
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "radial-gradient(circle at top, #1f2937 0, #020617 52%, #000 100%)",
        color: "#f9fafb",
        display: "flex",
        flexDirection: "column",
        fontFamily: "system-ui, sans-serif",
      }}
    >
      {/* TOP BAR */}
      <header
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "10px 18px",
          borderBottom: "1px solid #374151",
          background:
            "linear-gradient(90deg, rgba(15,23,42,0.95), rgba(17,24,39,0.95))",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div
            style={{
              width: 32,
              height: 32,
              borderRadius: "50%",
              background:
                "conic-gradient(from 0deg, #ff006e, #8338ec, #3a86ff, #06ffa5, #ff006e)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 18,
            }}
          >
            💲
          </div>
          <div>
            <div style={{ fontWeight: 700, letterSpacing: "0.04em" }}>
              OMEGABET
            </div>
            <div style={{ fontSize: 11, color: "#9ca3af" }}>
              Saldo compartido en todos los juegos
            </div>
          </div>
        </div>

        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
          }}
        >
          <div
            style={{
              fontSize: 12,
              padding: "4px 8px",
              borderRadius: 999,
              backgroundColor: "#111827",
              border: "1px solid #374151",
            }}
          >
            {globalMessage}
          </div>

          <button
            onClick={() => setWalletOpen(true)}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 6,
              padding: "6px 10px",
              borderRadius: 999,
              border: "1px solid #facc15",
              background:
                "linear-gradient(135deg, rgba(250,204,21,0.15), rgba(56,189,248,0.1))",
              cursor: "pointer",
            }}
          >
            <span
              style={{
                width: 20,
                height: 20,
                borderRadius: 6,
                background:
                  "linear-gradient(135deg, #facc15, #fb923c, #f97316)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "#111827",
                fontSize: 14,
              }}
            >
              👛
            </span>
            <span style={{ fontSize: 12, color: "#d1d5db" }}>Saldo</span>
            <span
              style={{
                fontFamily: "monospace",
                fontWeight: 700,
                color: "#22c55e",
              }}
            >
              {balance.toFixed(2)}
            </span>
          </button>
        </div>
      </header>

      {/* CONTENIDO */}
      <main style={{ flex: 1, position: "relative" }}>
        {currentGame === null ? (
          <GameGridMenu balance={balance} setCurrentGame={setCurrentGame} />
        ) : (
          <FullScreenGame
            game={currentGame}
            balance={balance}
            setBalance={setBalance}
            onBack={() => setCurrentGame(null)}
          />
        )}
      </main>

      {walletOpen && (
        <WalletModal
          mode={walletMode}
          setMode={setWalletMode}
          amount={walletAmount}
          setAmount={setWalletAmount}
          password={walletPassword}
          setPassword={setWalletPassword}
          onClose={() => setWalletOpen(false)}
          onConfirm={handleWalletConfirm}
        />
      )}
    </div>
  );
};

export default App;

/* -------------------- MENÚ DE JUEGOS -------------------- */

type GameGridProps = {
  balance: number;
  setCurrentGame: (g: GameKey) => void;
};

const GameGridMenu: React.FC<GameGridProps> = ({ setCurrentGame }) => {
  const games: { key: GameKey; icon: string; label: string; desc: string }[] = [
    { key: "mines", icon: "💣", label: "Mines 5x5", desc: "Evita las minas, cobra cuando quieras" },
    { key: "limbo", icon: "📈", label: "Limbo", desc: "Multiplicador hasta 100x con animación" },
    { key: "blackjack", icon: "🃏", label: "Blackjack", desc: "Juega manos completas contra la banca" },
    { key: "baccarat", icon: "🎴", label: "Baccarat", desc: "Jugador, banca o empate" },
    { key: "races", icon: "🏁", label: "Carreras", desc: "Apuesta a uno de 4 coches de colores" },
    { key: "roulette", icon: "🎡", label: "Ruleta", desc: "Ruleta tipo casino, rojo o negro" },
  ];

  return (
    <div
      style={{
        height: "100%",
        padding: "30px 40px",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <div
        style={{
          maxWidth: 1200,
          width: "100%",
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
          gap: 24,
        }}
      >
        {games.map((g) => (
          <button
            key={g.key}
            onClick={() => setCurrentGame(g.key)}
            style={{
              borderRadius: 20,
              padding: 20,
              border: "2px solid rgba(255, 107, 107, 0.6)",
              background: `linear-gradient(135deg, rgba(${Math.random() * 100 + 100}, ${Math.random() * 100 + 50}, 255, 0.15), rgba(255, ${Math.random() * 100 + 100}, 200, 0.1))`,
              backdropFilter: "blur(10px)",
              cursor: "pointer",
              textAlign: "left",
              display: "flex",
              flexDirection: "column",
              gap: 12,
              boxShadow: "0 15px 35px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.1)",
              transition: "all 0.3s ease",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = "translateY(-8px)";
              e.currentTarget.style.boxShadow = "0 25px 50px rgba(255, 0, 127, 0.4), inset 0 1px 0 rgba(255,255,255,0.1)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = "translateY(0)";
              e.currentTarget.style.boxShadow = "0 15px 35px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.1)";
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div
                style={{
                  width: 50,
                  height: 50,
                  borderRadius: 16,
                  background:
                    "linear-gradient(135deg, rgba(255, 107, 107, 0.3), rgba(100, 200, 255, 0.3))",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: 28,
                  border: "2px solid rgba(255, 107, 107, 0.5)",
                }}
              >
                {g.icon}
              </div>
              <div
                style={{
                  padding: "4px 10px",
                  borderRadius: 999,
                  fontSize: 11,
                  border: "1px solid rgba(255, 107, 107, 0.7)",
                  color: "#ff6b6b",
                  fontWeight: 600,
                  background: "rgba(255, 107, 107, 0.1)",
                }}
              >
                JUGAR
              </div>
            </div>
            <div>
              <div style={{ fontWeight: 700, marginBottom: 6, fontSize: 16, background: "linear-gradient(135deg, #ff006e, #8338ec)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>{g.label}</div>
              <div style={{ fontSize: 13, color: "#b0b0b0" }}>{g.desc}</div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

/* -------------------- WRAPPER PANTALLA COMPLETA -------------------- */

type FullScreenProps = {
  game: GameKey;
  balance: number;
  setBalance: React.Dispatch<React.SetStateAction<number>>;
  onBack: () => void;
};

const FullScreenGame: React.FC<FullScreenProps> = ({
  game,
  balance,
  setBalance,
  onBack,
}) => {
  const titleMap: Record<GameKey, string> = {
    mines: "Mines 5x5",
    limbo: "Limbo",
    blackjack: "Blackjack",
    baccarat: "Baccarat",
    races: "Carreras",
    roulette: "Ruleta",
  };

  let content: React.ReactNode = null;

  const commonProps: GameProps = { balance, setBalance };

  switch (game) {
    // slot removed
    case "mines":
      content = <MinesGame {...commonProps} />;
      break;
    case "limbo":
      content = <LimboGame {...commonProps} />;
      break;
    case "blackjack":
      content = <BlackjackGame {...commonProps} />;
      break;
    case "baccarat":
      content = <BaccaratGame {...commonProps} />;
      break;
    case "races":
      content = <RacesGame {...commonProps} />;
      break;
    case "roulette":
      content = <RouletteGame {...commonProps} />;
      break;
  }

  return (
    <div
      style={{
        height: "calc(100vh - 56px)",
        padding: 16,
        display: "flex",
        flexDirection: "column",
      }}
    >
      <div
        style={{
          marginBottom: 10,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <button
          onClick={onBack}
          style={{
            padding: "6px 10px",
            borderRadius: 999,
            border: "1px solid #374151",
            backgroundColor: "#020617",
            color: "#e5e7eb",
            fontSize: 12,
            cursor: "pointer",
          }}
        >
          ← Volver al menú
        </button>
        <div style={{ fontSize: 14, fontWeight: 600 }}>{titleMap[game]}</div>
        <div style={{ width: 100 }} />
      </div>

      <div
        style={{
          flex: 1,
          borderRadius: 18,
          border: "1px solid #374151",
          background:
            "radial-gradient(circle at top, #111827 0, #020617 50%, #020617 100%)",
          padding: 16,
          overflow: "hidden",
        }}
      >
        {content}
      </div>
    </div>
  );
};

/* -------------------- MODAL CARTERA -------------------- */

type WalletProps = {
  mode: "deposit" | "withdraw";
  setMode: (m: "deposit" | "withdraw") => void;
  amount: string;
  setAmount: (v: string) => void;
  password: string;
  setPassword: (v: string) => void;
  onClose: () => void;
  onConfirm: () => void;
};

const WalletModal: React.FC<WalletProps> = ({
  mode,
  setMode,
  amount,
  setAmount,
  password,
  setPassword,
  onClose,
  onConfirm,
}) => {
  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        backgroundColor: "rgba(0,0,0,0.7)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 50,
      }}
    >
      <div
        style={{
          width: "100%",
          maxWidth: 360,
          backgroundColor: "#020617",
          borderRadius: 14,
          border: "1px solid #4b5563",
          padding: 16,
          boxShadow: "0 20px 45px rgba(0,0,0,0.8)",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            marginBottom: 8,
          }}
        >
          <div style={{ fontWeight: 600 }}>Cartera</div>
          <button
            onClick={onClose}
            style={{
              background: "none",
              border: "none",
              color: "#9ca3af",
              cursor: "pointer",
              fontSize: 16,
            }}
          >
            ✕
          </button>
        </div>

        <div
          style={{
            display: "flex",
            gap: 8,
            marginBottom: 10,
            fontSize: 12,
          }}
        >
          <button
            onClick={() => setMode("deposit")}
            style={{
              flex: 1,
              padding: "6px 0",
              borderRadius: 999,
              border: mode === "deposit" ? "1px solid #22c55e" : "1px solid #374151",
              backgroundColor: mode === "deposit" ? "#052e16" : "#020617",
              color: mode === "deposit" ? "#bbf7d0" : "#e5e7eb",
              cursor: "pointer",
            }}
          >
            Ingresar
          </button>
          <button
            onClick={() => setMode("withdraw")}
            style={{
              flex: 1,
              padding: "6px 0",
              borderRadius: 999,
              border: mode === "withdraw" ? "1px solid #f97316" : "1px solid #374151",
              backgroundColor: mode === "withdraw" ? "#431407" : "#020617",
              color: mode === "withdraw" ? "#fed7aa" : "#e5e7eb",
              cursor: "pointer",
            }}
          >
            Retirar
          </button>
        </div>

        <div style={{ marginBottom: 8, fontSize: 12 }}>
          Cantidad
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            style={{
              marginTop: 4,
              width: "100%",
              padding: "6px 8px",
              borderRadius: 8,
              border: "1px solid #374151",
              backgroundColor: "#020617",
              color: "#e5e7eb",
            }}
          />
        </div>
        <div style={{ marginBottom: 12, fontSize: 12 }}>
          Contraseña
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={{
              marginTop: 4,
              width: "100%",
              padding: "6px 8px",
              borderRadius: 8,
              border: "1px solid #374151",
              backgroundColor: "#020617",
              color: "#e5e7eb",
            }}
          />
        </div>
        <button
          onClick={onConfirm}
          style={{
            width: "100%",
            padding: "8px 0",
            borderRadius: 10,
            border: "none",
            background:
              "linear-gradient(135deg, #22c55e, #16a34a, #22c55e 90%)",
            color: "#052e16",
            fontWeight: 700,
            cursor: "pointer",
            fontSize: 14,
          }}
        >
          Confirmar
        </button>
      </div>
    </div>
  );
};

// Slot machine implementation and helpers removed per user request

/* -------------------- MINES 5x5 -------------------- */

type MinesState = "idle" | "playing" | "exploded" | "cashed";

const MinesGame: React.FC<GameProps> = ({ balance, setBalance }) => {
  const [bet, setBet] = useState("1");
  const [mines, setMines] = useState(3);
  const [board, setBoard] = useState<number[]>(() => Array(25).fill(0));
  const [revealed, setRevealed] = useState<boolean[]>(() => Array(25).fill(false));
  const [state, setState] = useState<MinesState>("idle");
  const [safeRevealed, setSafeRevealed] = useState(0);
  const [multiplier, setMultiplier] = useState(1);
  const [minesMessage, setMinesMessage] = useState<string>("");

  const totalCells = 25;

  function startRound() {
    const amount = Number(bet);
    if (!isFinite(amount) || amount <= 0) {
      setMinesMessage("Apuesta inválida.");
      return;
    }
    if (amount > balance) {
      setMinesMessage("Saldo insuficiente.");
      return;
    }
    if (mines < 1 || mines >= totalCells) {
      setMinesMessage("Número de minas inválido.");
      return;
    }
    setBalance((b) => b - amount);
    setMinesMessage("");

    const cells = Array(totalCells).fill(0);
    const mineIndexes = new Set<number>();
    while (mineIndexes.size < mines) {
      mineIndexes.add(Math.floor(Math.random() * totalCells));
    }
    mineIndexes.forEach((i) => (cells[i] = 1));

    setBoard(cells);
    setRevealed(Array(totalCells).fill(false));
    setSafeRevealed(0);
    setState("playing");
    setMultiplier(1);
  }

  function computeMultiplier(safeCount: number): number {
    const safeTotal = totalCells - mines;
    if (safeCount <= 0) return 1;
    let probSafeSequence = 1;
    for (let i = 0; i < safeCount; i++) {
      probSafeSequence *= (safeTotal - i) / (totalCells - i);
    }
    const fair = 1 / probSafeSequence;
    // borde de la casa ~4% => RTP ~96%
    return fair * 0.96;
  }

  function clickCell(idx: number) {
    if (state !== "playing") return;
    if (revealed[idx]) return;

    const newRev = [...revealed];
    newRev[idx] = true;
    setRevealed(newRev);

    if (board[idx] === 1) {
      setState("exploded");
      setMinesMessage("Pisaste una mina. Ronda perdida.");
      return;
    }

    const newSafe = safeRevealed + 1;
    setSafeRevealed(newSafe);
    const newMult = computeMultiplier(newSafe);
    setMultiplier(newMult);
  }

  function cashout() {
    if (state !== "playing") return;
    const amount = Number(bet);
    if (!isFinite(amount) || amount <= 0) return;
    const win = amount * multiplier;
    setBalance((b) => b + win);
    setState("cashed");
    setMinesMessage(`¡Cobras ${win.toFixed(2)} créditos!`);
  }

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <h2 style={{ marginTop: 0 }}>💣 Mines 5x5</h2>
      <p style={{ fontSize: 12, color: "#9ca3af" }}>
        Elige minas (1–24). Cuantas más minas, mayor el riesgo y la recompensa. ¡Atrévete a cavar!
      </p>

      <div style={{ display: "flex", gap: 12, marginBottom: 8, alignItems: "center" }}>
        <label style={{ fontSize: 14, display: "flex", flexDirection: "column", gap: 6 }}>
          <span style={{ fontSize: 12, color: "#9ca3af" }}>Apuesta</span>
          <input
            type="number"
            value={bet}
            onChange={(e) => setBet(e.target.value)}
            style={{
              width: 140,
              marginLeft: 0,
              padding: "10px 12px",
              borderRadius: 10,
              border: "1px solid #374151",
              backgroundColor: "#020617",
              color: "#e5e7eb",
              fontSize: 16,
            }}
          />
        </label>
        <label style={{ fontSize: 14, display: "flex", flexDirection: "column", gap: 6 }}>
          <span style={{ fontSize: 12, color: "#9ca3af" }}>Minas</span>
          <input
            type="number"
            min={1}
            max={24}
            value={mines}
            onChange={(e) => setMines(Number(e.target.value))}
            style={{
              width: 80,
              marginLeft: 0,
              padding: "8px 10px",
              borderRadius: 10,
              border: "1px solid #374151",
              backgroundColor: "#020617",
              color: "#e5e7eb",
              fontSize: 16,
            }}
          />
        </label>
        <div style={{ marginLeft: "auto", textAlign: "right" }}>
          <div style={{ fontSize: 12, color: "#9ca3af" }}>Mult actual</div>
          <div style={{ fontSize: 28, fontWeight: 800, color: "#facc15" }}>x{multiplier.toFixed(2)}</div>
        </div>
      </div>

      {minesMessage && (
        <div style={{ marginBottom: 8, padding: 10, borderRadius: 8, background: "rgba(0,0,0,0.45)", border: "1px solid rgba(255,255,255,0.04)", color: "#ffd7d7", fontWeight: 700 }}>
          {minesMessage}
        </div>
      )}

      <div
        style={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          gap: 16,
        }}
      >
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(5, 1fr)",
            gridTemplateRows: "repeat(5, 1fr)",
            gap: 10,
            width: "100%",
            maxWidth: 600,
            aspectRatio: "1",
          }}
        >
          {board.map((cell, idx) => {
          const isRev = revealed[idx];
          let bg = "#020617";
          let symbol = "❓";
          if (state === "exploded" && cell === 1) {
            bg = "#7f1d1d";
            symbol = "💥";
          } else if (isRev && cell === 1) {
            bg = "#7f1d1d";
            symbol = "💥";
          } else if (isRev && cell === 0) {
            bg = "#064e3b";
            symbol = "💎";
          }
          return (
            <button
              key={idx}
              onClick={() => clickCell(idx)}
              style={{
                borderRadius: 10,
                border: "1px solid #374151",
                backgroundColor: bg,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 22,
                cursor: state === "playing" && !isRev ? "pointer" : "default",
              }}
            >
              {symbol}
            </button>
          );
        })}
        </div>
      </div>

      <div style={{ marginTop: 12, display: "flex", gap: 12, justifyContent: "center", alignItems: "center" }}>
        <button
          onClick={startRound}
          style={{
            padding: "12px 20px",
            borderRadius: 12,
            border: "none",
            background: "linear-gradient(135deg, #22c55e, #16a34a)",
            color: "#052e16",
            fontWeight: 800,
            fontSize: 16,
            cursor: "pointer",
            minWidth: 160,
          }}
        >
          Nueva ronda
        </button>
        <button
          onClick={cashout}
          disabled={state !== "playing"}
          style={{
            padding: "12px 20px",
            borderRadius: 12,
            border: "none",
            background: state === "playing" ? "linear-gradient(135deg, #facc15, #eab308)" : "#4b5563",
            color: state === "playing" ? "#111827" : "#9ca3af",
            fontWeight: 800,
            fontSize: 16,
            cursor: state === "playing" ? "pointer" : "default",
            minWidth: 160,
          }}
        >
          Cobrar
        </button>
      </div>
    </div>
  );
};

/* -------------------- LIMBO ANIMADO -------------------- */

const LimboGame: React.FC<GameProps> = ({ balance, setBalance }) => {
  const [bet, setBet] = useState("1");
  const [target, setTarget] = useState("2");
  const [displayMult, setDisplayMult] = useState(1);
  const [running, setRunning] = useState(false);
  const [resultText, setResultText] = useState<string>("");
  const [winProbability, setWinProbability] = useState(0);
  const [resultColor, setResultColor] = useState<"green" | "red" | null>(null);

  function play() {
    if (running) return;
    const amount = Number(bet);
    if (!isFinite(amount) || amount <= 0) {
      setResultText("Apuesta inválida.");
      return;
    }
    let t = Number(target);
    if (!isFinite(t) || t < 1.1) t = 1.1;
    if (t > 100) t = 100;
    if (amount > balance) {
      setResultText("Saldo insuficiente.");
      return;
    }

    setBalance((b) => b - amount);

    // Calcular probabilidad real: 98/t (sin edge)
    let prob = 98 / t;
    if (prob > 98) prob = 98;
    setWinProbability(prob);

    // Aplicar probabilidad
    const win = Math.random() < (prob / 100);

    let visualEnd: number;
    let effectiveMult: number;

    if (win) {
      effectiveMult = t;
      visualEnd = t + Math.random() * 0.3;
    } else {
      effectiveMult = 0;
      visualEnd = Math.min(1 + (t - 1) * (0.5 + Math.random() * 0.4), t - 0.05);
    }

    setRunning(true);
    setResultText("");
    setResultColor(null);
    setDisplayMult(1);
    
    animateMultiplier(1, visualEnd, 900, (val, done) => {
      setDisplayMult(val);
      if (done) {
        setRunning(false);
        if (win) {
          const winAmount = amount * effectiveMult;
          setBalance((b) => b + winAmount);
          setResultText(`¡GANADOR! x${effectiveMult.toFixed(2)} = +${winAmount.toFixed(2)}`);
          setResultColor("green");
        } else {
          setResultText("¡PÉRDIDA!");
          setResultColor("red");
        }
      }
    });
  }

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <h2 style={{ marginTop: 0 }}>📈 Limbo</h2>
      <p style={{ fontSize: 12, color: "#9ca3af" }}>
        El multiplicador sube en tiempo real. Si supera tu objetivo, ¡ganas! Probabilidad mostrada abajo.
      </p>

      <div style={{ display: "flex", gap: 16, marginBottom: 8 }}>
        <label style={{ fontSize: 12 }}>
          Apuesta
          <input
            type="number"
            value={bet}
            onChange={(e) => setBet(e.target.value)}
            disabled={running}
            style={{
              width: 80,
              marginLeft: 6,
              padding: "4px 6px",
              borderRadius: 6,
              border: "1px solid #374151",
              backgroundColor: "#020617",
              color: "#e5e7eb",
            }}
          />
        </label>
        <label style={{ fontSize: 12 }}>
          Objetivo (1.1 - 100x)
          <input
            type="number"
            value={target}
            onChange={(e) => setTarget(e.target.value)}
            disabled={running}
            style={{
              width: 100,
              marginLeft: 6,
              padding: "4px 6px",
              borderRadius: 6,
              border: "1px solid #374151",
              backgroundColor: "#020617",
              color: "#e5e7eb",
            }}
          />
        </label>
        <div style={{ fontSize: 12, paddingTop: 8 }}>
          % Ganar: <span style={{ color: "#ff6b9d", fontWeight: 700 }}>{winProbability.toFixed(1)}%</span>
        </div>
      </div>

      <div
        style={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          gap: 16,
        }}
      >
        <div
          style={{
            fontSize: running ? 140 + (displayMult - 1) * 30 : 140,
            fontFamily: "monospace",
            fontWeight: 800,
            color: resultColor === "green" ? "#22c55e" : resultColor === "red" ? "#ef4444" : "#38bdf8",
            transition: running ? "font-size 0.05s linear" : "all 0.3s ease",
            textShadow: `0 0 20px ${resultColor === "green" ? "rgba(34, 197, 94, 0.7)" : resultColor === "red" ? "rgba(239, 68, 68, 0.7)" : "rgba(56, 189, 248, 0.5)"}`,
          }}
        >
          x{displayMult.toFixed(2)}
        </div>
        <div
          style={{
            fontSize: 14,
            minHeight: 20,
            textAlign: "center",
            color: resultColor === "green" ? "#22c55e" : resultColor === "red" ? "#ef4444" : "#9ca3af",
            fontWeight: resultText ? 700 : 400,
          }}
        >
          {resultText}
        </div>
      </div>

      <button
        onClick={play}
        disabled={running}
        style={{
          width: "100%",
          padding: "12px 0",
          borderRadius: 999,
          border: "none",
          background: running
            ? "#4b5563"
            : "linear-gradient(135deg, #ff006e, #8338ec, #3a86ff)",
          color: running ? "#9ca3af" : "#fff",
          fontWeight: 800,
          cursor: running ? "default" : "pointer",
          fontSize: 15,
        }}
      >
        {running ? "En curso..." : "JUGAR"}
      </button>
    </div>
  );
};

function animateMultiplier(
  from: number,
  to: number,
  duration: number,
  cb: (v: number, done: boolean) => void
) {
  const start = performance.now();
  function frame(now: number) {
    const t = Math.min((now - start) / duration, 1);
    const eased = 1 - Math.pow(1 - t, 3);
    const val = from + (to - from) * eased;
    cb(val, t >= 1);
    if (t < 1) requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
}

/* -------------------- BLACKJACK (como antes, resumido) -------------------- */

type BJCard = { rank: number; suit: string };

function drawCard(): BJCard {
  const suits = ["♠", "♥", "♦", "♣"];
  return {
    rank: Math.floor(Math.random() * 13) + 1,
    suit: suits[Math.floor(Math.random() * suits.length)],
  };
}
function cardLabel(c: BJCard) {
  const map: Record<number, string> = { 1: "A", 11: "J", 12: "Q", 13: "K" };
  return (map[c.rank] || c.rank.toString()) + c.suit;
}
function handValue(hand: BJCard[]): number {
  let total = 0;
  let aces = 0;
  for (const c of hand) {
    if (c.rank === 1) {
      aces++;
      total += 11;
    } else if (c.rank >= 10) total += 10;
    else total += c.rank;
  }
  while (total > 21 && aces > 0) {
    total -= 10;
    aces--;
  }
  return total;
}
type BJState = "betting" | "player" | "dealer" | "finished";

const BlackjackGame: React.FC<GameProps> = ({ balance, setBalance }) => {
  const [bet, setBet] = useState("1");
  const [state, setState] = useState<BJState>("betting");
  const [player, setPlayer] = useState<BJCard[]>([]);
  const [dealer, setDealer] = useState<BJCard[]>([]);
  const [result, setResult] = useState("");
  const [doubled, setDoubled] = useState(false);

  function startHand() {
    const amount = Number(bet);
    if (!isFinite(amount) || amount <= 0) return alert("Apuesta inválida.");
    if (amount > balance) return alert("Saldo insuficiente.");
    setBalance((b) => b - amount);
    setPlayer([drawCard(), drawCard()]);
    setDealer([drawCard(), drawCard()]);
    setState("player");
    setResult("");
    setDoubled(false);
  }
  
  function hit() {
    if (state !== "player") return;
    const newHand = [...player, drawCard()];
    setPlayer(newHand);
    if (handValue(newHand) > 21) finish("bust");
  }
  
  function doubleDown() {
    if (state !== "player" || doubled || player.length !== 2) return;
    const amount = Number(bet);
    if (amount > balance) {
      alert("No tienes saldo suficiente para doblar.");
      return;
    }
    setBalance((b) => b - amount);
    setDoubled(true);
    const newHand = [...player, drawCard()];
    setPlayer(newHand);
    if (handValue(newHand) > 21) {
      finish("bust");
    } else {
      playerStand(newHand);
    }
  }
  
  function stand() {
    if (state !== "player") return;
    playerStand(player);
  }
  
  function playerStand(playerHand: BJCard[]) {
    setState("dealer");
    let d = [...dealer];
    while (handValue(d) < 17) {
      d = [...d, drawCard()];
    }
    setDealer(d);
    const pv = handValue(playerHand);
    const dv = handValue(d);
    
    if (pv > 21) {
      finish("bust");
    } else if (dv > 21) {
      finish("dealerBust");
    } else if (pv > dv) {
      finish("player");
    } else if (pv < dv) {
      finish("dealer");
    } else {
      finish("push");
    }
  }
  
  function finish(outcome: "bust" | "dealerBust" | "player" | "dealer" | "push") {
    const amount = Number(bet);
    let delta = 0;
    let text = "";
    const multiplier = doubled ? 2 : 1;
    
    switch (outcome) {
      case "bust":
        text = "¡Te pasaste! Pierdes.";
        break;
      case "dealerBust":
        delta = amount * 2 * multiplier;
        text = `¡La banca se pasa! ¡Ganas ${delta.toFixed(2)}!`;
        break;
      case "player":
        const isBlackjack = player.length === 2 && handValue(player) === 21;
        if (isBlackjack && !doubled) {
          delta = amount * 2.5;
          text = `¡BLACKJACK! ¡Ganas ${delta.toFixed(2)}!`;
        } else {
          delta = amount * 2 * multiplier;
          text = `¡Tu mano gana! ¡Ganas ${delta.toFixed(2)}!`;
        }
        break;
      case "dealer":
        text = "La banca gana.";
        break;
      case "push":
        delta = amount * multiplier;
        text = `Empate. Se devuelven ${delta.toFixed(2)}.`;
        break;
    }
    if (delta > 0) setBalance((b) => b + delta);
    setResult(text);
    setState("finished");
  }
  
  function reset() {
    setState("betting");
    setPlayer([]);
    setDealer([]);
    setResult("");
    setDoubled(false);
  }

  const pv = handValue(player);
  const dv = handValue(dealer);
  const canDouble = state === "player" && !doubled && player.length === 2;

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <h2 style={{ marginTop: 0 }}>🃏 Blackjack</h2>
      <div style={{ marginBottom: 6, fontSize: 12, color: "#9ca3af" }}>
        Consigue 21 o acércate más que la banca. Blackjack (21 en 2 cartas) = 2.5x. Doblar multiplica tu apuesta.
      </div>

      <div style={{ marginBottom: 8, fontSize: 12 }}>
        Apuesta{" "}
        <input
          type="number"
          value={bet}
          onChange={(e) => setBet(e.target.value)}
          disabled={state !== "betting"}
          style={{
            width: 80,
            marginLeft: 4,
            padding: "4px 6px",
            borderRadius: 6,
            border: "1px solid #374151",
            backgroundColor: "#020617",
            color: "#e5e7eb",
          }}
        />
      </div>

      <div
        style={{
          flex: 1,
          display: "grid",
          gridTemplateRows: "1fr 1fr",
          gap: 10,
        }}
      >
        <div
          style={{
            borderRadius: 12,
            background:
              "linear-gradient(135deg, rgba(148,163,184,0.12), rgba(15,23,42,0.9))",
            border: "1px solid #4b5563",
            padding: 10,
          }}
        >
          <div style={{ fontSize: 12, marginBottom: 6 }}>Banca</div>
          <div style={{ display: "flex", gap: 6, marginBottom: 4 }}>
            {dealer.map((c, i) => (
              <SmallCard key={i} label={cardLabel(c)} />
            ))}
          </div>
          <div style={{ fontSize: 12, color: "#e5e7eb" }}>Total: {dv}</div>
        </div>
        <div
          style={{
            borderRadius: 12,
            background:
              "linear-gradient(135deg, rgba(34,197,94,0.12), rgba(15,23,42,0.9))",
            border: "1px solid #22c55e",
            padding: 10,
          }}
        >
          <div style={{ fontSize: 12, marginBottom: 6 }}>Jugador</div>
          <div style={{ display: "flex", gap: 6, marginBottom: 4 }}>
            {player.map((c, i) => (
              <SmallCard key={i} label={cardLabel(c)} />
            ))}
          </div>
          <div style={{ fontSize: 12, color: "#bbf7d0 " }}>Total: {pv}</div>
        </div>
      </div>

      <div
        style={{
          marginTop: 8,
          display: "flex",
          gap: 8,
          justifyContent: "space-between",
          flexWrap: "wrap",
        }}
      >
        {state === "betting" && (
          <button
            onClick={startHand}
            style={{
              flex: 1,
              minWidth: 100,
              padding: "10px 0",
              borderRadius: 10,
              border: "none",
              background:
                "linear-gradient(135deg, #22c55e, #16a34a, #22c55e 90%)",
              color: "#052e16",
              fontWeight: 700,
              cursor: "pointer",
            }}
          >
            JUGAR
          </button>
        )}
        {state === "player" && (
          <>
            <button
              onClick={hit}
              style={{
                flex: 1,
                minWidth: 100,
                padding: "10px 0",
                borderRadius: 10,
                border: "none",
                background:
                  "linear-gradient(135deg, #38bdf8, #0ea5e9, #38bdf8 90%)",
                color: "#022c22",
                fontWeight: 700,
                cursor: "pointer",
              }}
            >
              Pedir
            </button>
            {canDouble && (
              <button
                onClick={doubleDown}
                style={{
                  flex: 1,
                  minWidth: 100,
                  padding: "10px 0",
                  borderRadius: 10,
                  border: "none",
                  background:
                    "linear-gradient(135deg, #ff006e, #8338ec, #ff006e 90%)",
                  color: "#fff",
                  fontWeight: 700,
                  cursor: "pointer",
                }}
              >
                Doblar
              </button>
            )}
            <button
              onClick={stand}
              style={{
                flex: 1,
                minWidth: 100,
                padding: "10px 0",
                borderRadius: 10,
                border: "none",
                background:
                  "linear-gradient(135deg, #facc15, #eab308, #facc15 90%)",
                color: "#713f12",
                fontWeight: 700,
                cursor: "pointer",
              }}
            >
              Plantarse
            </button>
          </>
        )}
        {state === "finished" && (
          <button
            onClick={reset}
            style={{
              flex: 1,
              minWidth: 100,
              padding: "10px 0",
              borderRadius: 10,
              border: "none",
              background:
                "linear-gradient(135deg, #6366f1, #4f46e5, #6366f1 90%)",
              color: "#eef2ff",
              fontWeight: 700,
              cursor: "pointer",
            }}
          >
            Nueva Mano
          </button>
        )}
      </div>

      <div
        style={{
          marginTop: 6,
          fontSize: 13,
          color: result.includes("gana") || result.includes("BLACKJACK") ? "#22c55e" : "#fca5a5",
          minHeight: 16,
          fontWeight: result ? 700 : 400,
        }}
      >
        {result}
      </div>
    </div>
  );
};

const SmallCard: React.FC<{ label: string }> = ({ label }) => (
  <div
    style={{
      width: 40,
      height: 56,
      borderRadius: 8,
      border: "1px solid #e5e7eb",
      backgroundColor: "#f9fafb",
      color: "#111827",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: 18,
      fontWeight: 700,
    }}
  >
    {label}
  </div>
);

/* -------------------- BACCARAT -------------------- */

const BaccaratGame: React.FC<GameProps> = ({ balance, setBalance }) => {
  const [bet, setBet] = useState("1");
  const [choice, setChoice] = useState<"player" | "banker" | "tie">("player");
  const [playerCards, setPlayerCards] = useState<BJCard[]>([]);
  const [bankerCards, setBankerCards] = useState<BJCard[]>([]);
  const [status, setStatus] = useState("Haz tu apuesta y reparte.");
  const [isDealing, setIsDealing] = useState(false);

  function baccaratValue(cards: BJCard[]): number {
    let total = 0;
    for (const c of cards) {
      if (c.rank >= 10) total += 0;
      else if (c.rank === 1) total += 1;
      else total += c.rank;
    }
    return total % 10;
  }

  function deal() {
    const amount = Number(bet);
    if (!isFinite(amount) || amount <= 0) return alert("Apuesta inválida.");
    if (amount > balance) return alert("Saldo insuficiente.");
    setBalance((b) => b - amount);
    setIsDealing(true);

    const playerFirst = [drawCard()];
    const bankerFirst = [drawCard()];

    setPlayerCards(playerFirst);
    setBankerCards(bankerFirst);
    setStatus("Repartiendo...");

    setTimeout(() => {
      const playerSecond = [drawCard()];
      setPlayerCards([...playerFirst, ...playerSecond]);
      setStatus("Cartas repartidas. Determinando ganador...");

      setTimeout(() => {
        const bankerSecond = [drawCard()];
        setBankerCards([...bankerFirst, ...bankerSecond]);

        const pv = baccaratValue([...playerFirst, ...playerSecond]);
        const bv = baccaratValue([...bankerFirst, ...bankerSecond]);

        let winner: "player" | "banker" | "tie";
        if (pv > bv) winner = "player";
        else if (bv > pv) winner = "banker";
        else winner = "tie";

        let payout = 0;
        if (winner === "player" && choice === "player") payout = amount * 2;
        if (winner === "banker" && choice === "banker") payout = amount * 1.95;
        if (winner === "tie" && choice === "tie") payout = amount * 8;

        if (payout > 0) {
          setBalance((bal) => bal + payout);
          setStatus(
            `¡${
              winner === "player" ? "Jugador" : winner === "banker" ? "Banca" : "Empate"
            } gana! ¡Cobras ${payout.toFixed(2)}!`
          );
        } else {
          setStatus(
            `${
              winner === "player" ? "Jugador" : winner === "banker" ? "Banca" : "Empate"
            } gana. Pierdes.`
          );
        }
        setIsDealing(false);
      }, 800);
    }, 800);
  }

  const pv = playerCards.length > 0 ? baccaratValue(playerCards) : 0;
  const bv = bankerCards.length > 0 ? baccaratValue(bankerCards) : 0;

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <h2 style={{ marginTop: 0 }}>🎴 Baccarat</h2>
      <p style={{ fontSize: 12, color: "#9ca3af" }}>
        Apuesta a Jugador, Banca o Empate. Se reparten cartas y se calcula el valor.
      </p>

      <div style={{ display: "flex", gap: 12, marginBottom: 12 }}>
        <label style={{ fontSize: 12 }}>
          Apuesta
          <input
            type="number"
            value={bet}
            onChange={(e) => setBet(e.target.value)}
            disabled={isDealing}
            style={{
              width: 80,
              marginLeft: 4,
              padding: "4px 6px",
              borderRadius: 6,
              border: "1px solid #374151",
              backgroundColor: "#020617",
              color: "#e5e7eb",
            }}
          />
        </label>
        <label style={{ fontSize: 12 }}>
          Apuesta a
          <select
            value={choice}
            onChange={(e) =>
              setChoice(e.target.value as "player" | "banker" | "tie")
            }
            disabled={isDealing}
            style={{
              marginLeft: 4,
              padding: "4px 6px",
              borderRadius: 6,
              border: "1px solid #374151",
              backgroundColor: "#020617",
              color: "#e5e7eb",
            }}
          >
            <option value="player">Jugador</option>
            <option value="banker">Banca</option>
            <option value="tie">Empate</option>
          </select>
        </label>
      </div>

      <div
        style={{
          flex: 1,
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 16,
        }}
      >
        <div
          style={{
            borderRadius: 16,
            border: "2px solid #38bdf8",
            background:
              "linear-gradient(135deg, rgba(56,189,248,0.15), rgba(15,23,42,0.95))",
            padding: 16,
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
          }}
        >
          <div>
            <div style={{ marginBottom: 12, fontSize: 13, fontWeight: 600 }}>Jugador</div>
            <div style={{ display: "flex", gap: 10, minHeight: 100, alignItems: "flex-start", justifyContent: "center" }}>
              {playerCards.map((c, i) => (
                <div
                  key={i}
                  style={{
                    animation: isDealing && i === playerCards.length - 1 ? "slideIn 0.6s ease-out" : "none",
                  }}
                >
                  <SmallCard label={cardLabel(c)} />
                </div>
              ))}
            </div>
          </div>
          <div style={{ fontSize: 28, fontWeight: 800, color: "#38bdf8", textAlign: "center" }}>
            {pv}
          </div>
        </div>

        <div
          style={{
            borderRadius: 16,
            border: "2px solid #f97316",
            background:
              "linear-gradient(135deg, rgba(249,115,22,0.15), rgba(15,23,42,0.95))",
            padding: 16,
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
          }}
        >
          <div>
            <div style={{ marginBottom: 12, fontSize: 13, fontWeight: 600 }}>Banca</div>
            <div style={{ display: "flex", gap: 10, minHeight: 100, alignItems: "flex-start", justifyContent: "center" }}>
              {bankerCards.map((c, i) => (
                <div
                  key={i}
                  style={{
                    animation: isDealing && i === bankerCards.length - 1 ? "slideIn 0.6s ease-out" : "none",
                  }}
                >
                  <SmallCard label={cardLabel(c)} />
                </div>
              ))}
            </div>
          </div>
          <div style={{ fontSize: 28, fontWeight: 800, color: "#f97316", textAlign: "center" }}>
            {bv}
          </div>
        </div>
      </div>

      <style>
        {`@keyframes slideIn { from { transform: translateY(-20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }`}
      </style>

      <div
        style={{
          fontSize: 13,
          textAlign: "center",
          marginTop: 12,
          minHeight: 20,
          color: status.includes("¡") ? "#22c55e" : status.includes("Pierdes") ? "#ef4444" : "#9ca3af",
          fontWeight: status.includes("¡") || status.includes("Pierdes") ? 700 : 400,
        }}
      >
        {status}
      </div>

      <button
        onClick={deal}
        disabled={isDealing}
        style={{
          width: "100%",
          padding: "12px 0",
          marginTop: 8,
          borderRadius: 10,
          border: "none",
          background: isDealing
            ? "#4b5563"
            : "linear-gradient(135deg, #ff006e, #8338ec, #3a86ff)",
          color: isDealing ? "#9ca3af" : "#fff",
          fontWeight: 700,
          cursor: isDealing ? "default" : "pointer",
          fontSize: 14,
        }}
      >
        {isDealing ? "Repartiendo..." : "REPARTIR"}
      </button>
    </div>
  );
};

/* -------------------- CARRERAS 4 COCHES CON ANIMACIÓN -------------------- */

const RacesGame: React.FC<GameProps> = ({ balance, setBalance }) => {
  const [bet, setBet] = useState("1");
  const [choice, setChoice] = useState<0 | 1 | 2 | 3>(0);
  const [positions, setPositions] = useState([0, 0, 0, 0]);
  const [running, setRunning] = useState(false);
  const [resultText, setResultText] = useState("");

  const colors = ["#ef4444", "#22c55e", "#3b82f6", "#f97316"];
  const names = ["Rojo", "Verde", "Azul", "Naranja"];

  function startRace() {
    if (running) return;
    const amount = Number(bet);
    if (!isFinite(amount) || amount <= 0) return alert("Apuesta inválida.");
    if (amount > balance) return alert("Saldo insuficiente.");

    setBalance((b) => b - amount);
    setRunning(true);
    setPositions([0, 0, 0, 0]);
    setResultText("");

    // Generar velocidades aleatorias con near miss incorporado
    const willWin = Math.random() < 0.24;
    const winIndex = willWin ? choice : Math.floor(Math.random() * 4);
    
    // Crear velocidades: el ganador es rápido, otros más lentos
    const speeds = [0, 0, 0, 0].map((_, i) => {
      if (i === winIndex) return 0.8 + Math.random() * 0.2; // Rápido: 0.8-1.0
      else return 0.3 + Math.random() * 0.4; // Lento: 0.3-0.7
    });

    let currentPos = [0, 0, 0, 0];
    let hasWinner = false;

    const animationInterval = setInterval(() => {
      currentPos = currentPos.map((pos, idx) => {
        const newPos = Math.min(pos + speeds[idx] * 2, 100);
        if (newPos >= 100 && !hasWinner) {
          hasWinner = true;
          clearInterval(animationInterval);
          setRunning(false);
          
          if (idx === choice) {
            const winAmount = amount * 4;
            setBalance((b) => b + winAmount);
            setResultText(`¡Tu bola ${names[idx]} ganó! ¡Cobras ${winAmount.toFixed(2)} créditos!`);
          } else {
            setResultText(`¡Ganó la bola ${names[idx]}! Mejor suerte la próxima.`);
          }
        }
        return newPos;
      });
      setPositions(currentPos);
    }, 50);

    setTimeout(() => {
      if (!hasWinner) {
        clearInterval(animationInterval);
      }
    }, 4000);
  }

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <h2 style={{ marginTop: 0 }}>🏁 Carreras de Bolas</h2>
      <p style={{ fontSize: 12, color: "#9ca3af" }}>
        Elige una bola. ¡Que sea la más rápida!
      </p>

      <div style={{ display: "flex", gap: 12, marginBottom: 12 }}>
        <label style={{ fontSize: 12 }}>
          Apuesta
          <input
            type="number"
            value={bet}
            onChange={(e) => setBet(e.target.value)}
            disabled={running}
            style={{
              width: 80,
              marginLeft: 4,
              padding: "4px 6px",
              borderRadius: 6,
              border: "1px solid #374151",
              backgroundColor: "#020617",
              color: "#e5e7eb",
            }}
          />
        </label>
        <div style={{ display: "flex", gap: 8, fontSize: 12 }}>
          {names.map((name, idx) => (
            <button
              key={idx}
              onClick={() => !running && setChoice(idx as 0 | 1 | 2 | 3)}
              style={{
                padding: "6px 12px",
                borderRadius: 999,
                border:
                  choice === idx
                    ? `2px solid ${colors[idx]}`
                    : "1px solid #374151",
                backgroundColor:
                  choice === idx ? "rgba(15,23,42,0.9)" : "#020617",
                color: "#e5e7eb",
                cursor: running ? "default" : "pointer",
                display: "flex",
                alignItems: "center",
                gap: 6,
                fontWeight: choice === idx ? 700 : 400,
              }}
            >
              <span
                style={{
                  width: 12,
                  height: 12,
                  borderRadius: 999,
                  backgroundColor: colors[idx],
                  border: choice === idx ? `2px solid #fff` : "none",
                }}
              />
              {name}
            </button>
          ))}
        </div>
      </div>

      <div
        style={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-around",
          padding: "20px 10px",
          borderRadius: 12,
          backgroundColor: "rgba(0,0,0,0.2)",
        }}
      >
        {colors.map((c, idx) => (
          <div key={idx} style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ fontSize: 11, minWidth: 50 }}>{names[idx]}</div>
            <div
              style={{
                flex: 1,
                height: 40,
                borderRadius: 999,
                background: "linear-gradient(90deg, rgba(30,30,30,0.8), rgba(60,60,60,0.6))",
                border: `2px solid ${c}`,
                position: "relative",
                overflow: "hidden",
              }}
            >
              <div
                style={{
                  position: "absolute",
                  left: `${positions[idx]}%`,
                  top: "50%",
                  transform: "translate(-50%, -50%)",
                  width: 32,
                  height: 32,
                  borderRadius: "50%",
                  backgroundColor: c,
                  boxShadow: `0 0 15px ${c}, inset 0 0 5px rgba(255,255,255,0.5)`,
                  transition: "left 0.05s linear",
                  border: "2px solid rgba(255,255,255,0.8)",
                }}
              />
            </div>
          </div>
        ))}
      </div>

      <div
        style={{
          fontSize: 13,
          textAlign: "center",
          marginTop: 12,
          minHeight: 20,
          color: resultText.includes("¡Tu") ? "#22c55e" : resultText ? "#ff6b9d" : "#9ca3af",
          fontWeight: resultText ? 700 : 400,
        }}
      >
        {resultText || (running ? "¡Las bolas compiten!" : "Presiona JUGAR para comenzar")}
      </div>

      <button
        onClick={startRace}
        disabled={running}
        style={{
          width: "100%",
          padding: "12px 0",
          marginTop: 8,
          borderRadius: 10,
          border: "none",
          background: running
            ? "#4b5563"
            : "linear-gradient(135deg, #f97316, #fb923c, #facc15)",
          color: running ? "#9ca3af" : "#111827",
          fontWeight: 700,
          cursor: running ? "default" : "pointer",
          fontSize: 14,
        }}
      >
        {running ? "Corriendo..." : "JUGAR"}
      </button>
    </div>
  );
};

/* -------------------- RULETA ESTILO CASINO -------------------- */

const RouletteGame: React.FC<GameProps> = ({ balance, setBalance }) => {
  const [bet, setBet] = useState("1");
  const [selectedNumber, setSelectedNumber] = useState<number | null>(null);
  const [spinning, setSpinning] = useState(false);
  const [resultNumber, setResultNumber] = useState<number | null>(null);
  const [resultText, setResultText] = useState("");
  const [betMode, setBetMode] = useState<"number" | "color">("number");
  const [selectedColor, setSelectedColor] = useState<"red" | "black" | null>(null);

  const getNumberColor = (num: number): "red" | "black" | "green" => {
    if (num === 0) return "green";
    return num % 2 === 0 ? "red" : "black";
  };

  function handleSpin() {
    if (spinning) return;
    if (betMode === "number" && selectedNumber === null) {
      setResultText("Selecciona un número");
      return;
    }
    if (betMode === "color" && selectedColor === null) {
      setResultText("Selecciona Rojo o Negro");
      return;
    }
    const amount = Number(bet);
    if (!isFinite(amount) || amount <= 0) {
      setResultText("Apuesta inválida.");
      return;
    }
    if (amount > balance) {
      setResultText("Saldo insuficiente.");
      return;
    }

    setBalance((b) => b - amount);
    setSpinning(true);
    setResultText("Girando...");
    setResultNumber(null);

    // Resultado aleatorio: 0-36
    const landed = Math.floor(Math.random() * 37);
    const landedColor = getNumberColor(landed);

    setTimeout(() => {
      setSpinning(false);
      setResultNumber(landed);

      if (betMode === "number") {
        if (landed === selectedNumber) {
          const winAmount = amount * 36;
          setBalance((b) => b + winAmount);
          setResultText(`¡GANADOR! ${landed} - ¡Cobras ${winAmount.toFixed(2)}!`);
        } else {
          setResultText(`Sale ${landed} (${landedColor}). Pierdes.`);
        }
      } else {
        // color bet: win 2x on correct color (0 always loses)
        if (landed !== 0 && landedColor === selectedColor) {
          const winAmount = amount * 2;
          setBalance((b) => b + winAmount);
          setResultText(`¡GANADOR por color! ${landed} (${landedColor}) - +${winAmount.toFixed(2)}`);
        } else {
          setResultText(`Sale ${landed} (${landedColor}). Pierdes.`);
        }
      }
    }, 1600);
  }

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <h2 style={{ marginTop: 0 }}>🎡 Ruleta Clásica</h2>
      <p style={{ fontSize: 12, color: "#9ca3af" }}>
        Apuesta a un número del 0 al 36. Aciertas el número exacto y ganas 36x.
      </p>

      <div style={{ display: "flex", gap: 12, marginBottom: 12, alignItems: "center" }}>
        <label style={{ fontSize: 14, display: "flex", flexDirection: "column", gap: 6 }}>
          <span style={{ fontSize: 12, color: "#9ca3af" }}>Apuesta</span>
          <input
            type="number"
            value={bet}
            onChange={(e) => setBet(e.target.value)}
            disabled={spinning}
            style={{
              width: 120,
              marginLeft: 0,
              padding: "8px 10px",
              borderRadius: 8,
              border: "1px solid #374151",
              backgroundColor: "#020617",
              color: "#e5e7eb",
              fontSize: 16,
            }}
          />
        </label>

        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <label style={{ fontSize: 12 }}>
            <input type="radio" name="betMode" checked={betMode === "number"} onChange={() => { setBetMode("number"); setResultText(""); }} /> Número
          </label>
          <label style={{ fontSize: 12 }}>
            <input type="radio" name="betMode" checked={betMode === "color"} onChange={() => { setBetMode("color"); setResultText(""); }} /> Color
          </label>
          {betMode === "color" && (
            <div style={{ display: "flex", gap: 6, marginLeft: 8 }}>
              <button onClick={() => setSelectedColor("red")} disabled={spinning} style={{ padding: "6px 10px", borderRadius: 6, background: selectedColor === "red" ? "#ef4444" : "#1f1f1f", color: "#fff", border: "none" }}>Rojo</button>
              <button onClick={() => setSelectedColor("black")} disabled={spinning} style={{ padding: "6px 10px", borderRadius: 6, background: selectedColor === "black" ? "#111" : "#efefef", color: selectedColor === "black" ? "#fff" : "#111", border: "none" }}>Negro</button>
            </div>
          )}

        </div>

        <div style={{ fontSize: 12 }}>
          Seleccionado: <span style={{ color: "#ff6b9d", fontWeight: 700 }}>{betMode === "number" ? (selectedNumber !== null ? selectedNumber : "Ninguno") : (selectedColor ?? "Ninguno")}</span>
        </div>
      </div>

      <div
        style={{
          flex: 1,
          display: "grid",
          gridTemplateColumns: "repeat(7, 1fr)",
          gap: 8,
          marginBottom: 12,
          overflowY: "auto",
        }}
      >
        {[0, ...Array.from({length: 36}, (_, i) => i + 1)].map((num) => {
          const color = getNumberColor(num);
          const bgColor = color === "red" ? "#ef4444" : color === "black" ? "#1f1f1f" : "#22c55e";
          const isSelected = selectedNumber === num;
          
          return (
            <button
              key={num}
              onClick={() => !spinning && setSelectedNumber(num)}
              style={{
                aspectRatio: "1",
                borderRadius: 8,
                border: isSelected ? "3px solid #fff" : "2px solid rgba(255,255,255,0.2)",
                background: bgColor,
                color: color === "black" ? "#fff" : color === "green" ? "#000" : "#fff",
                fontWeight: 700,
                fontSize: 12,
                cursor: spinning ? "default" : "pointer",
                opacity: resultNumber === num ? 1 : 0.8,
                transform: isSelected ? "scale(1.1)" : "scale(1)",
                transition: "all 0.2s",
              }}
            >
              {num}
            </button>
          );
        })}
      </div>

      <div
        style={{
          display: "flex",
          gap: 10,
          alignItems: "center",
          justifyContent: "center",
          marginBottom: 12,
        }}
      >
        <div
          style={{
            width: 100,
            height: 100,
            borderRadius: "50%",
            border: "4px solid #f97316",
            background: spinning ? "conic-gradient(from 0deg, #ef4444, #1f1f1f, #22c55e, #ef4444)" : "#1f2937",
            animation: spinning ? "spin 3s linear infinite" : "none",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontWeight: 800,
            fontSize: 32,
            color: "#fff",
          }}
        >
          {resultNumber !== null ? resultNumber : "?"}
        </div>
        <style>
          {`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}
        </style>
      </div>

      <div
        style={{
          fontSize: 13,
          textAlign: "center",
          minHeight: 18,
          marginBottom: 10,
          color: resultText.includes("GANADOR") ? "#22c55e" : "#fca5a5",
          fontWeight: resultText ? 700 : 400,
        }}
      >
        {resultText}
      </div>

      <button
        onClick={handleSpin}
        disabled={spinning || selectedNumber === null}
        style={{
          width: "100%",
          padding: "12px 0",
          borderRadius: 10,
          border: "none",
          background: spinning || selectedNumber === null
            ? "#4b5563"
            : "linear-gradient(135deg, #f97316, #fb923c, #facc15)",
          color: spinning || selectedNumber === null ? "#9ca3af" : "#111827",
          fontWeight: 700,
          cursor: spinning || selectedNumber === null ? "default" : "pointer",
          fontSize: 14,
        }}
      >
        {spinning ? "Girando..." : "GIRAR"}
      </button>
    </div>
  );
};
